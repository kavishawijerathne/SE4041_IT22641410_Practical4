package com.example.madd_practical04

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnNavAdd = findViewById<Button>(R.id.btnNavAdd)
        val btnNavView = findViewById<Button>(R.id.btnNavView)

        // Load the Add Todo screen by default
        if (savedInstanceState == null) {
            loadFragment(AddTodoFragment())
        }

        btnNavAdd.setOnClickListener {
            loadFragment(AddTodoFragment())
        }

        btnNavView.setOnClickListener {
            loadFragment(ViewTodosFragment())
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}