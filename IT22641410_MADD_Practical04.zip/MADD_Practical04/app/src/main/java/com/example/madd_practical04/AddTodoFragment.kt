package com.example.madd_practical04

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment

class AddTodoFragment : Fragment(R.layout.fragment_add_todo) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etTodoItem = view.findViewById<EditText>(R.id.etTodoItem)
        val btnAddTodo = view.findViewById<Button>(R.id.btnAddTodo)

        btnAddTodo.setOnClickListener {
            val taskText = etTodoItem.text.toString()
            if (taskText.isNotEmpty()) {
                TodoData.todoList.add(Todo(taskText))
                etTodoItem.text.clear()
                Toast.makeText(requireContext(), "Added!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}