package com.example.madd_practical04

data class Todo(val task: String)