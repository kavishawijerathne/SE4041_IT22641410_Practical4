package com.example.madd_practical04

object TodoData {
    val todoList = mutableListOf<Todo>()
}